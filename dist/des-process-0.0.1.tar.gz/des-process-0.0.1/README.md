# DES Process (Dark Energy Survey Portal Process)

## What is it?
**[DES Process](https://github.com/linea-it/des-process)** is a collection of functions for fetching processes and products from DES portal.